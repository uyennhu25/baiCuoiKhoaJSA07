function carousel(x, y) {
    if (z.matches) {
        $(document).ready(function () {
            $('.carousel').slick({
                slidesToShow: 1,
                dots: false,
                arrow: false,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 2000,
                pauseOnFocus: true,
                swipe: false,
                focusOnSelect: true,
            });
        });
    } else if (y.matches) {
        $(document).ready(function () {
            $('.carousel').slick({
                slidesToShow: 2,
                dots: false,
                arrow: false,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 2000,
                pauseOnFocus: true,
                swipe: false,
                focusOnSelect: true,
            });
        });

    } else if (x.matches) {
        $(document).ready(function () {
            $('.carousel').slick({
                slidesToShow: 3,
                dots: false,
                arrow: false,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 2000,
                pauseOnFocus: true,
                swipe: false,
                focusOnSelect: true,
            });
        });

    } else {
        $(document).ready(function () {
            $('.carousel').slick({
                slidesToShow: 3,
                dots: false,
                centerMode: true,
                arrow: false,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 2000,
                pauseOnFocus: true,
                swipe: false,
                focusOnSelect: true,
            });
        });
    }
}

var x = window.matchMedia("(max-width: 1300px)")
var y = window.matchMedia("(max-width: 1120px)")
var z = window.matchMedia("(max-width: 800px)")
carousel(x, y, z)



$(document).ready(function () {
    $('.popular-destinations').slick({
        slidesToShow: 3,
        arrow: true,
        nextArrow: document.getElementById('slick-next'),
        prevArrow: document.getElementById('slick-prev'),
        swipe: false,
        variableWidth: true,
    });
});

$(document).ready(function () {
    $('.phuQuoc-carousel').slick({
        slidesToShow: 1,
        centerMode: true,
        dots: true,
        swipe: false,
    });
});

var form = document.getElementById('form_card')
var submit1 = document.getElementById('submit1')
var submit2 = document.getElementById('submit2')

function signUp_process() {
    var nameInput = document.getElementById('name').value
    var passwordInput = document.getElementById('password').value
    var confirmPassword = document.getElementById('confirmpassword').value

    if ((passwordInput != "") && (nameInput != "") && (confirmPassword != "")) {
        console.log('signupsuccess')

        if (confirmPassword != passwordInput) {
            alert("...")
        }

        console.log(nameInput.value, passwordInput)
        localStorage.setItem(nameInput, passwordInput)

        document.getElementById('name').value = ""
        document.getElementById('password').value = ""
        document.getElementById('confirmpassword').value = ""

        alert("Signed Up Successful")
    }
}

function logIn_process() {
    var nameInput = document.getElementById('name').value
    var passwordInput = document.getElementById('password').value

     if (localStorage.getItem(nameInput) !== null) {
        if (passwordInput == localStorage.getItem(nameInput)) {
            alert("Loged In Successful")
        } else{
            alert ("Wrong password")
        }
     } else {
        alert ("Account does not exist")
     }
}

let login = document.getElementById('login')

login.addEventListener('click', logIn)


function logIn() {
    form.innerHTML = `
        <h3 style="color: white;" >Đăng nhập</h3>
        <input type="text" name="name" id="name" placeholder=" Nhập tên người dùng" />
        <input type="password" name="password" id="password" placeholder=" Nhập mật khẩu" style="margin-bottom: 2px;" />
        <button type="submit" id="submit1" onclick="logIn_process()">Submit</button>`
    form.style.display = "block"
    form.style.height = "310px"
}

let signup = document.getElementById('signup')

signup.addEventListener('click', signUp)

function signUp() {
    form.innerHTML = `
        <h3 style="color: white;" >Đăng kí</h3>
        <input type="text" name="name" id="name" placeholder=" Nhập tên người dùng" />
        <input type="password" name="password" id="password" placeholder=" Nhập mật khẩu" />
        <input type="password" name="confirmpassword" id="confirmpassword" placeholder=" Xác nhận mật khẩu" style="margin-bottom: 2px;" />
        <button type="submit" id="submit2" onclick="signUp_process()">Submit</button>`
    form.style.display = "block"
    form.style.height = "370px"
}


document.addEventListener('click', function (e) {
    if ((!form.contains(e.target)) && (!login.contains(e.target)) && (!signup.contains(e.target)) && (form.style.display == "block")) {
        form.style.display = "none";
        console.log('success')
    }
});

function readMore(order) {
    var dots = document.querySelector(`.saiGon-desc[order="${order}"] .dots`);
    var moreText = document.querySelector(`.saiGon-desc[order="${order}"] .more`);
    var readbth = document.querySelector(`.saiGon-desc[order="${order}"] .readbth`);

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        readbth.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        readbth.innerHTML = "Read less";
        moreText.style.display = "inline";
    }
}


$('.destination').css('display', 'none');

function hoiAn() {
    $('.destination').css('display', 'none');
    $('#hoiAn').css('display', 'initial');
}

function phuQuoc() {
    $('.destination').css('display', 'none');
    $('#phuQuoc').css('display', 'initial');
}

function nhaTrang() {
    $('.destination').css('display', 'none');
    $('#nhaTrang').css('display', 'initial');
}

function saiGon() {
    $('.destination').css('display', 'none');
    $('#saiGon').css('display', 'initial');
}

function quangBinh() {
    $('.destination').css('display', 'none');
    $('#quangBinh').css('display', 'initial');
}

function daLat() {
    $('.destination').css('display', 'none');
    $('#daLat').css('display', 'initial');
}

$(document).scroll(function () {
    var y = $(this).scrollTop();
    if (y > 400) {
        $('.top_bth').fadeIn();
    } else {
        $('.top_bth').fadeOut();
    }
});

